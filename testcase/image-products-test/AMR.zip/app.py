from flask import Flask, render_template, request
import requests
import json

app = Flask(__name__, static_url_path='/static')

API_URL = "https://api-inference.huggingface.co/models/SamLowe/roberta-base-go_emotions"
API_TOKEN = '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'
headers = {"Authorization": f"Bearer {API_TOKEN}"}

def query(payload):
    response = requests.post(API_URL, headers=headers, json=payload)
    return response.json()

def fetch_fear_and_greed_index():
    response = requests.get("https://api.alternative.me/fng/")
    data = response.json()
    return data['data'][0]['value']

# Categorize labels into negative, neutral, positive
def categorize_labels(labels):
    with open('emotion_scores.json', 'r') as file:
        label_scores = json.load(file)
    
    categorized_labels = {"negative": [], "neutral": [], "positive": [], "top": []}
    
    top_label = labels[0]["label"]
    top_score = label_scores.get(top_label, 50)  # Default to 50 for unknown labels
    categorized_labels["top"].append({"label": top_label, "score": top_score})
    
    for label in labels:
        label_name = label["label"]
        label_score = label_scores.get(label_name, 50)  # Default to 50 for unknown labels
        label_with_score = {"label": label_name, "score": label_score}
        
        if label_score <= 20:
            categorized_labels["negative"].append(label_with_score)
        elif label_score >= 80:
            categorized_labels["positive"].append(label_with_score)
        else:
            categorized_labels["neutral"].append(label_with_score)
    
    return categorized_labels
@app.route('/', methods=['GET', 'POST'])
def index():
    fear_and_greed_index = fetch_fear_and_greed_index()
    input_text = ""
    categorized_labels = None

    if request.method == 'POST':
        input_text = request.form['input_text']
        output = query({
            "inputs": input_text,
        })

        if 'error' in output:
            error_message = output['error']
            return render_template('index.html', error=error_message)

        top_labels = output[0]
        categorized_labels = categorize_labels(top_labels)
    
    return render_template('index.html', fear_and_greed_index=fear_and_greed_index, input_text=input_text, categorized_labels=categorized_labels, top_labels= top_labels[:4])

if __name__ == '__main__':
    app.run(debug=True)
